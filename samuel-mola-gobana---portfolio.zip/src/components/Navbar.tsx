import React, { useState } from 'react';
import { developerProfile } from '../data/portfolioData';

interface NavbarProps {
  isDark: boolean;
  onToggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ isDark, onToggleTheme }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="site-header fixed inset-x-0 top-0 z-50">
      <div className="wrap flex flex-wrap items-center justify-between gap-2 py-3">
        {/* Logo matching devsolan: DevSamuel */}
        <a href="#home" className="logo font-bold text-xl no-underline" aria-label="Samuel Mola, home">
          Dev<span>Samuel</span>
        </a>

        {/* Action Controls */}
        <div className="flex items-center gap-2 md:order-last">
          <button
            id="theme-toggle"
            onClick={onToggleTheme}
            className="btn text-sm"
            type="button"
            aria-label="Toggle theme"
          >
            {isDark ? 'Light' : 'Dark'}
          </button>

          <a className="btn btn-primary hidden sm:inline-flex" href="#contact">
            Hire Me
          </a>

          <button
            id="menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="btn md:hidden text-sm"
            type="button"
            aria-expanded={mobileMenuOpen}
            aria-controls="site-nav"
          >
            Menu
          </button>
        </div>

        {/* Navigation Links */}
        <nav
          id="site-nav"
          aria-label="Main"
          className={`${
            mobileMenuOpen ? 'flex' : 'hidden'
          } w-full flex-col gap-1 pb-2 md:flex md:w-auto md:flex-row md:pb-0`}
        >
          <a
            className="nav-link"
            href="#home"
            onClick={() => setMobileMenuOpen(false)}
          >
            Home
          </a>
          <a
            className="nav-link"
            href="#about"
            onClick={() => setMobileMenuOpen(false)}
          >
            About
          </a>
          <a
            className="nav-link"
            href="#skills"
            onClick={() => setMobileMenuOpen(false)}
          >
            Skills
          </a>
          <a
            className="nav-link"
            href="#projects"
            onClick={() => setMobileMenuOpen(false)}
          >
            Projects
          </a>
          <a
            className="nav-link"
            href="#education"
            onClick={() => setMobileMenuOpen(false)}
          >
            Education
          </a>
          <a
            className="nav-link"
            href="#contact"
            onClick={() => setMobileMenuOpen(false)}
          >
            Contact
          </a>
        </nav>
      </div>
    </header>
  );
};
