import React from 'react';

export const Journey: React.FC = () => {
  return (
    <section id="journey" className="sec">
      <div className="wrap">
        <p className="kicker">Journey</p>
        <h2 className="h2">Learning journey</h2>

        <div className="grid gap-4 md:grid-cols-3">
          <div className="card">
            <h3 className="font-semibold mb-1 text-base">Personal projects</h3>
            <p className="muted text-sm leading-relaxed">
              I learn by building complete apps end to end, from the University Lost and Found recovery system to a machine learning student performance predictor.
            </p>
          </div>

          <div className="card">
            <h3 className="font-semibold mb-1 text-base">Teamwork</h3>
            <p className="muted text-sm leading-relaxed">
              University group work taught me to split tasks, review each other&apos;s code, test edge cases, and communicate progress clearly.
            </p>
          </div>

          <div className="card">
            <h3 className="font-semibold mb-1 text-base">Open source and internships</h3>
            <p className="muted text-sm leading-relaxed">
              I&apos;m looking for internships and collaborative software projects to contribute to and grow within real production codebases.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
