import React from 'react';
import { portfolioProjects, ProjectItem } from '../data/portfolioData';

interface ProjectsProps {
  onOpenLostAndFoundDemo: () => void;
  onOpenStudentPredictionDemo: () => void;
}

export const Projects: React.FC<ProjectsProps> = ({
  onOpenLostAndFoundDemo,
  onOpenStudentPredictionDemo,
}) => {
  const handleLaunchDemo = (project: ProjectItem) => {
    if (project.liveDemoType === 'lost_and_found') {
      onOpenLostAndFoundDemo();
    } else if (project.liveDemoType === 'student_prediction') {
      onOpenStudentPredictionDemo();
    } else if (project.demo && project.demo.startsWith('http')) {
      window.open(project.demo, '_blank');
    }
  };

  return (
    <section id="projects" className="sec">
      <div className="wrap">
        <p className="kicker">Portfolio</p>
        <h2 className="h2">Featured projects</h2>

        <div id="projects-grid" className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {portfolioProjects.map((project) => (
            <article key={project.id} className="card flex flex-col justify-between">
              <div>
                {/* Screenshot image */}
                {project.image && (
                  <img
                    src={project.image}
                    alt={`${project.title} screenshot`}
                    className="project-screenshot rounded-lg mb-4 w-full"
                    loading="lazy"
                  />
                )}

                {/* Title & Status Badge */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <h3 className="text-lg font-bold font-display">{project.title}</h3>
                  <span className="badge">{project.status}</span>
                </div>

                {/* Description */}
                <p className="muted mb-3 text-sm leading-relaxed">{project.description}</p>

                {/* Problem Statement */}
                {project.problem && (
                  <p className="text-sm mb-3">
                    <strong>Problem: </strong>
                    <span className="muted">{project.problem}</span>
                  </p>
                )}

                {/* Features list */}
                {project.features && project.features.length > 0 && (
                  <ul className="text-sm muted list-disc pl-5 mb-4 space-y-1">
                    {project.features.map((feature, idx) => (
                      <li key={idx}>{feature}</li>
                    ))}
                  </ul>
                )}

                {/* Technology chips */}
                <div className="mb-4">
                  {project.tech.map((tech) => (
                    <span key={tech} className="chip">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Links */}
              <div className="mt-auto pt-3 border-t border-[var(--line)] flex flex-wrap gap-2">
                {project.repo && (
                  <a
                    className="btn text-sm"
                    href={project.repo}
                    target="_blank"
                    rel="noopener"
                  >
                    Repository
                  </a>
                )}

                {project.liveDemoType ? (
                  <button
                    type="button"
                    className="btn btn-primary text-sm"
                    onClick={() => handleLaunchDemo(project)}
                  >
                    Live demo
                  </button>
                ) : project.demo ? (
                  <a
                    className="btn btn-primary text-sm"
                    href={project.demo}
                    target="_blank"
                    rel="noopener"
                  >
                    Live demo
                  </a>
                ) : null}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
