import React, { useState } from 'react';
import { X, Search, PlusCircle, CheckCircle2, Shield, MapPin, Calendar, Tag, AlertCircle } from 'lucide-react';

interface LostAndFoundDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ItemRecord {
  id: string;
  name: string;
  category: 'Electronics' | 'IDs & Cards' | 'Accessories' | 'Books & Stationery';
  type: 'lost' | 'found';
  location: string;
  date: string;
  finderOrOwner: string;
  status: 'Open' | 'Claimed' | 'In Custody';
  description: string;
}

const initialItems: ItemRecord[] = [
  {
    id: 'LF-101',
    name: 'Silver iPhone 13 (Clear Case)',
    category: 'Electronics',
    type: 'found',
    location: 'Central University Library - 2nd Floor Study Room',
    date: '2 hours ago',
    finderOrOwner: 'Library Security Desk',
    status: 'In Custody',
    description: 'Found near desk 42. Has a cracked glass screen protector and black phone lanyard.',
  },
  {
    id: 'LF-102',
    name: 'Student ID Card (Engineering Faculty)',
    category: 'IDs & Cards',
    type: 'found',
    location: 'Engineering Workshop Block B',
    date: 'Yesterday at 3:15 PM',
    finderOrOwner: 'Lab Assistant Office',
    status: 'In Custody',
    description: 'Name on card matches Department of Computer Science & Software Engineering.',
  },
  {
    id: 'LF-103',
    name: 'Black North Face Backpack',
    category: 'Accessories',
    type: 'lost',
    location: 'Main Campus Cafeteria Entrance',
    date: 'Yesterday evening',
    finderOrOwner: 'Student Report',
    status: 'Open',
    description: 'Contains notebook with Software Engineering lecture notes and water bottle.',
  },
  {
    id: 'LF-104',
    name: 'Casio fx-991EX Scientific Calculator',
    category: 'Books & Stationery',
    type: 'found',
    location: 'Mathematics Lecture Hall 3',
    date: 'Nov 5, 2026',
    finderOrOwner: 'Campus Custodian',
    status: 'In Custody',
    description: 'Found on front bench row. Has small green sticker on battery cover.',
  },
  {
    id: 'LF-105',
    name: 'Brass House Keys with Leather Keychain',
    category: 'Accessories',
    type: 'lost',
    location: 'Dormitory Quadrangle walkway',
    date: 'Nov 4, 2026',
    finderOrOwner: 'Student Report',
    status: 'Open',
    description: 'Ring with 3 silver keys and 1 brass key with a brown leather tag.',
  },
];

export const LostAndFoundDemoModal: React.FC<LostAndFoundDemoModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [items, setItems] = useState<ItemRecord[]>(initialItems);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [filterType, setFilterType] = useState<'all' | 'lost' | 'found'>('all');
  const [activeTab, setActiveTab] = useState<'browse' | 'report'>('browse');

  // Claim modal state
  const [claimingItem, setClaimingItem] = useState<ItemRecord | null>(null);
  const [claimProof, setClaimProof] = useState('');
  const [claimSuccess, setClaimSuccess] = useState(false);

  // New report form state
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState<'lost' | 'found'>('found');
  const [newCategory, setNewCategory] = useState<'Electronics' | 'IDs & Cards' | 'Accessories' | 'Books & Stationery'>('Electronics');
  const [newLocation, setNewLocation] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);

  if (!isOpen) return null;

  const categories = ['All', 'Electronics', 'IDs & Cards', 'Accessories', 'Books & Stationery'];

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesType = filterType === 'all' || item.type === filterType;
    return matchesSearch && matchesCategory && matchesType;
  });

  const handleCreateReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newLocation.trim()) return;

    const newItem: ItemRecord = {
      id: `LF-${Math.floor(100 + Math.random() * 900)}`,
      name: newName,
      category: newCategory,
      type: newType,
      location: newLocation,
      date: 'Just now',
      finderOrOwner: newType === 'found' ? 'Your Verified Submission' : 'Student Report',
      status: newType === 'found' ? 'In Custody' : 'Open',
      description: newDesc || 'Logged via University Lost & Found digital portal.',
    };

    setItems([newItem, ...items]);
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setActiveTab('browse');
      setNewName('');
      setNewLocation('');
      setNewDesc('');
    }, 1200);
  };

  const handleClaimSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!claimProof.trim()) return;
    setClaimSuccess(true);
    setTimeout(() => {
      if (claimingItem) {
        setItems(
          items.map((it) =>
            it.id === claimingItem.id ? { ...it, status: 'Claimed' } : it
          )
        );
      }
      setClaimSuccess(false);
      setClaimingItem(null);
      setClaimProof('');
    }, 1800);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto"
    >
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                University Lost & Found Campus Portal
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Interactive system demo developed by Samuel Mola Gobana · Live Campus Simulator
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
            <button
              onClick={() => setActiveTab('browse')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'browse'
                  ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Browse Inventory ({items.length})
            </button>
            <button
              onClick={() => setActiveTab('report')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'report'
                  ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5 text-blue-500" />
              <span>Report Item</span>
            </button>
          </div>

          <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
            <Shield className="w-3.5 h-3.5 text-emerald-500" />
            <span>Campus Security Verified</span>
          </div>
        </div>

        {/* Tab Content: Browse */}
        {activeTab === 'browse' && (
          <div className="p-6 space-y-4 max-h-[68vh] overflow-y-auto">
            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by item name, location, or details (e.g., iPhone, ID card, Keys)..."
                  className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Status Type Buttons */}
              <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg shrink-0">
                <button
                  onClick={() => setFilterType('all')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    filterType === 'all'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilterType('found')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    filterType === 'found'
                      ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Found
                </button>
                <button
                  onClick={() => setFilterType('lost')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    filterType === 'lost'
                      ? 'bg-white dark:bg-slate-700 text-amber-600 dark:text-amber-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Lost
                </button>
              </div>
            </div>

            {/* Category horizontal filters */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <span className="text-slate-400 text-xs shrink-0">Category:</span>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap ${
                    selectedCategory === cat
                      ? 'bg-blue-600 text-white font-medium'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Items List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  className="p-4 bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 rounded-xl hover:border-blue-400/50 dark:hover:border-blue-600/50 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-2 text-xs">
                        <span
                          className={`font-semibold ${
                            item.type === 'found'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-amber-600 dark:text-amber-400'
                          }`}
                        >
                          {item.type.toUpperCase()}
                        </span>
                        <span className="text-slate-400">·</span>
                        <span className="font-mono text-slate-400 text-xs">{item.id}</span>
                      </div>
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {item.status}
                      </span>
                    </div>

                    <h4 className="font-semibold text-slate-900 dark:text-slate-100 text-sm mb-1">
                      {item.name}
                    </h4>

                    <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mb-3">
                      {item.description}
                    </p>

                    <div className="space-y-1 text-xs text-slate-500 dark:text-slate-400">
                      <div className="flex items-center gap-1.5 truncate">
                        <MapPin className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                        <span className="truncate">{item.location}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{item.date}</span>
                        </div>
                        <span>·</span>
                        <div className="flex items-center gap-1">
                          <Tag className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{item.category}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-xs text-slate-400">
                      {item.finderOrOwner}
                    </span>
                    {item.status !== 'Claimed' ? (
                      <button
                        onClick={() => setClaimingItem(item)}
                        className="px-3 py-1 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors"
                      >
                        {item.type === 'found' ? 'Claim This Item' : 'I Found This'}
                      </button>
                    ) : (
                      <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Reclaimed by Owner</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {filteredItems.length === 0 && (
              <div className="p-8 text-center text-slate-400">
                <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm font-medium">
                  No items match your criteria.
                </p>
                <p className="text-xs mt-1">
                  Try another search query or report a new lost/found item.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Tab Content: Report */}
        {activeTab === 'report' && (
          <form onSubmit={handleCreateReport} className="p-6 space-y-4 max-h-[68vh] overflow-y-auto">
            {formSubmitted ? (
              <div className="p-8 text-center bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2 animate-bounce" />
                <h4 className="text-base font-bold text-emerald-900 dark:text-emerald-200">
                  Report Successfully Logged!
                </h4>
                <p className="text-xs text-emerald-700 dark:text-emerald-300 mt-1">
                  Campus registry updated. System notifications have been routed to matching reports.
                </p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Report Type
                    </label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setNewType('found')}
                        className={`flex-1 py-2 text-xs font-medium rounded-lg border transition-colors ${
                          newType === 'found'
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        I Found an Item
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewType('lost')}
                        className={`flex-1 py-2 text-xs font-medium rounded-lg border transition-colors ${
                          newType === 'lost'
                            ? 'bg-amber-600 text-white border-amber-600'
                            : 'border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        I Lost an Item
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Item Category
                    </label>
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100"
                    >
                      <option value="Electronics">Electronics (Phone, Laptop, Charger)</option>
                      <option value="IDs & Cards">IDs & Cards (Student ID, Bank Card)</option>
                      <option value="Accessories">Accessories (Bag, Keys, Watch, Glasses)</option>
                      <option value="Books & Stationery">Books & Stationery (Notebook, Calculator)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Item Title & Brand *
                  </label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g., HP Pavilion Laptop, Black Leather Wallet, Student ID..."
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Campus Location *
                  </label>
                  <input
                    type="text"
                    required
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    placeholder="e.g., Computer Lab 4, Library 2nd floor, Student Cafeteria..."
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Distinctive Features / Description
                  </label>
                  <textarea
                    rows={3}
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    placeholder="Specific markings, stickers, engravings, serial hints, or colors..."
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"
                  ></textarea>
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveTab('browse')}
                    className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
                  >
                    Submit Campus Report
                  </button>
                </div>
              </>
            )}
          </form>
        )}

        {/* Claim Sub-Modal */}
        {claimingItem && (
          <div className="absolute inset-0 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 z-20">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-xl max-w-md w-full shadow-2xl">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm font-display flex items-center gap-2">
                  <Shield className="w-4 h-4 text-blue-500" />
                  <span>Ownership Verification Check</span>
                </h4>
                <button
                  onClick={() => setClaimingItem(null)}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {claimSuccess ? (
                <div className="p-4 text-center">
                  <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2 animate-bounce" />
                  <p className="font-semibold text-emerald-900 dark:text-emerald-200 text-sm">
                    Ownership Claim Verified!
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Item matched with Campus Security desk. A retrieval QR token has been generated.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleClaimSubmit} className="space-y-3">
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    To verify you are the rightful owner of &ldquo;{claimingItem.name}&rdquo;, provide a distinctive identification detail (e.g. lock screen hint, scratch location, card number suffix):
                  </p>
                  <textarea
                    required
                    rows={3}
                    value={claimProof}
                    onChange={(e) => setClaimProof(e.target.value)}
                    placeholder="e.g., Blue sticker on backside, student ID ends in 4921, wallpaper is sunset..."
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
                  ></textarea>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setClaimingItem(null)}
                      className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
                    >
                      Verify & Claim
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-slate-950/50 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span>University Security Desk: Active Custody</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-md transition-colors"
          >
            Close Simulator
          </button>
        </div>
      </div>
    </div>
  );
};
