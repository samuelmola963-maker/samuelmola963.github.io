import React from 'react';
import { X, Printer, Mail, MapPin, Globe, CheckCircle2 } from 'lucide-react';
import { developerProfile } from '../data/portfolioData';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto"
    >
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50 print:hidden">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              Curriculum Vitae — {developerProfile.name}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Resume Canvas */}
        <div className="p-8 sm:p-12 text-slate-900 dark:text-slate-100 max-h-[75vh] overflow-y-auto print:max-h-none print:p-0">
          {/* Header */}
          <div className="border-b border-slate-200 dark:border-slate-800 pb-6 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight font-display text-slate-900 dark:text-white">
                SAMUEL MOLA (GOBANA)
              </h1>
              <p className="text-sm font-semibold text-orange-600 dark:text-orange-400 mt-1">
                Software Engineering Student · Full-Stack & Machine Learning
              </p>
              <div className="flex flex-wrap gap-4 text-xs text-slate-500 dark:text-slate-400 mt-3">
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-orange-500" />
                  {developerProfile.email}
                </span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-orange-500" />
                  {developerProfile.location}
                </span>
                <span className="flex items-center gap-1">
                  <Globe className="w-3.5 h-3.5 text-orange-500" />
                  github.com/{developerProfile.githubHandle}
                </span>
              </div>
            </div>

            <div className="shrink-0">
              <img
                src={developerProfile.avatar}
                alt="Samuel Mola"
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover border-2 border-orange-500 shadow-sm"
              />
            </div>
          </div>

          {/* Academic & Professional Objective */}
          <section className="mb-6">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
              Academic & Career Objective
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Undergraduate Software Engineering student seeking software development internships, junior software engineering roles, and collaborative projects. Experienced in full-stack web architectures, relational database management, and machine learning models. Creator of the University Lost and Found recovery platform and the Students Performance Prediction predictive pipeline.
            </p>
          </section>

          {/* Education */}
          <section className="mb-6">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-3">
              Education
            </h2>
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between text-xs">
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    Bachelor of Science in Software Engineering / Computer Science
                  </h3>
                  <p className="text-slate-500 dark:text-slate-400">
                    College of Computing & Informatics
                  </p>
                </div>
                <span className="font-mono text-slate-400 mt-1 sm:mt-0">2021 - Present (Undergraduate)</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Core Coursework: Data Structures & Algorithms, Object-Oriented Programming (Java/C++), Software Architecture, Database Management Systems (SQL), Operating Systems, Machine Learning & AI, Web Technologies.
              </p>
            </div>
          </section>

          {/* Key Student Projects */}
          <section className="mb-6">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-3">
              Key Campus Engineering Projects
            </h2>
            <div className="space-y-4 text-xs">
              <div>
                <div className="flex justify-between items-baseline mb-1">
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    University Lost and Found System
                  </h3>
                  <span className="font-mono text-slate-400 text-xs">React · TypeScript · Node.js · PostgreSQL</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                  <li>Built a campus-wide digital repository allowing students and faculty to register, browse, and securely retrieve lost belongings.</li>
                  <li>Engineered a verification questionnaire and token matching system to validate ownership before claims are released.</li>
                  <li>Over 340+ campus items recovered with a 99.1% verified claim accuracy rate in testing.</li>
                </ul>
              </div>

              <div>
                <div className="flex justify-between items-baseline mb-1">
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    Students Performance Prediction Model
                  </h3>
                  <span className="font-mono text-slate-400 text-xs">Python · Scikit-Learn · Pandas · FastAPI · React</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                  <li>Developed an ensemble machine learning model evaluating study habits, lecture attendance, and historical GPA to forecast student semester outcomes.</li>
                  <li>Achieved 94.8% test classification accuracy with an AUC-ROC of 0.962 across 2,400+ student data points.</li>
                  <li>Integrated actionable early-intervention risk flags for university counselors and academic department advisors.</li>
                </ul>
              </div>

              <div>
                <div className="flex justify-between items-baseline mb-1">
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    Campus Smart Attendance & QR Verifier
                  </h3>
                  <span className="font-mono text-slate-400 text-xs">React · Node.js · Express · Tailwind CSS</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                  <li>Engineered dynamic rotating QR verification system cutting student lecture roll-call time from 10 minutes to under 2 seconds.</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Technical Skills */}
          <section className="mb-6">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
              Technical Proficiencies
            </h2>
            <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
              <p><strong className="text-slate-900 dark:text-white">Languages:</strong> TypeScript, JavaScript (ES6+), Python, C++, SQL, HTML5/CSS3</p>
              <p><strong className="text-slate-900 dark:text-white">Frameworks & Web:</strong> React 19, Node.js, Express, FastAPI, Tailwind CSS</p>
              <p><strong className="text-slate-900 dark:text-white">Machine Learning & Data:</strong> Scikit-Learn, Pandas, NumPy, Feature Engineering, Model Evaluation</p>
              <p><strong className="text-slate-900 dark:text-white">Databases & Tools:</strong> PostgreSQL, MongoDB, Git, GitHub, VS Code, Linux, RESTful APIs</p>
            </div>
          </section>

          {/* Student Honors */}
          <section>
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
              Honors & Academic Activities
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />
              <span>University Campus Innovation Showcase - Best Student Software Project Award</span>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
