export interface ProjectItem {
  id: string;
  title: string;
  status: 'Completed' | 'In Progress';
  description: string;
  problem: string;
  features: string[];
  tech: string[];
  repo: string;
  demo?: string;
  image: string;
  liveDemoType?: 'lost_and_found' | 'student_prediction';
}

export interface AcademicProject {
  title: string;
  description: string;
  tech: string;
}
