export interface ProjectItem {
  id: string;
  title: string;
  status: 'Completed' | 'In Progress';
  description: string;
  problem: string;
  features: string[];
  tech: string[];
  repo: string;
  demo?: string;
  image: string;
  liveDemoType?: 'lost_and_found' | 'student_prediction';
}

export const developerProfile = {
  name: 'Samuel Mola',
  fullName: 'Samuel Mola Gobana',
  githubHandle: 'samuelmola963',
  title: 'Software Engineering Student & Full-Stack Developer',
  location: 'Ethiopia',
  email: 'samuelmola963@gmail.com',
  github: 'https://github.com/samuelmola963',
  linkedin: 'https://www.linkedin.com/in/samuel-mola',
  avatar: '/assets/aistudio/image_9f152f1c.png',
  avatarFallback: '/samuel_mola_portrait.png',
  education: 'BSc in Software Engineering',
  university: 'University College of Computing & Software Engineering',
  academicYears: '2022 to 2027',
  skills: {
    'Programming languages': ['Java', 'JavaScript', 'TypeScript', 'Python', 'C++', 'SQL'],
    'Frontend': ['HTML', 'CSS', 'Tailwind CSS', 'React', 'Next.js', 'Responsive Design'],
    'Mobile & Web': ['React Native', 'Progressive Web Apps'],
    'Backend': ['Node.js', 'Express', 'FastAPI', 'REST APIs', 'Java client-server programming'],
    'Databases': ['PostgreSQL', 'MongoDB', 'SQLite', 'Database Modeling'],
    'Deploy & Tools': ['Git', 'GitHub', 'GitHub Pages', 'Vite', 'Render', 'VS Code'],
    'Computer science': [
      'Data structures and algorithms',
      'Object-oriented programming',
      'Database fundamentals',
      'Software engineering principles',
      'Machine learning',
    ],
  },
  coursework: [
    'Data structures',
    'Databases',
    'Object-oriented programming',
    'Web and mobile development',
    'Software architecture',
    'Testing',
    'Networking',
    'Machine learning',
    'Security',
    'Distributed systems',
  ],
  academicProjects: [
    {
      title: 'University Lost and Found',
      description: 'Campus belongings retrieval system with ownership verification.',
      tech: 'React · Node.js · PostgreSQL',
    },
    {
      title: 'Students Performance Prediction',
      description: 'Machine learning model predicting academic risk and GPA.',
      tech: 'Python · Scikit-Learn · FastAPI',
    },
    {
      title: 'Campus QR Attendance System',
      description: 'Geofenced dynamic QR code attendance tracker for lecture halls.',
      tech: 'React · TypeScript · Express',
    },
  ],
};

export const portfolioProjects: ProjectItem[] = [
  {
    id: 'lost-and-found',
    title: 'University Lost and Found',
    status: 'Completed',
    description:
      'A full-stack campus web app for submitting, tracking, and resolving lost student belongings (ID cards, laptops, keys) with claim verification.',
    problem:
      'Organizations and universities lose track of lost items across scattered halls and paper notes, with no clear ownership, status, or retrieval history.',
    features: [
      'Role-based access (Student, Staff, Campus Security)',
      'Multi-filter campus inventory search (Location, Category, Date)',
      'Dual-party ownership verification quiz and claim tokens',
      'Automated email notifications when reported lost matches found report',
      'Centralized security locker custody audit logs',
    ],
    tech: ['React', 'TypeScript', 'Tailwind CSS', 'Node.js', 'PostgreSQL', 'REST API'],
    repo: 'https://github.com/samuelmola963/university-lost-and-found',
    demo: 'interactive',
    image: '/src/assets/images/project_lost_and_found_1793967644390.jpg',
    liveDemoType: 'lost_and_found',
  },
  {
    id: 'student-prediction',
    title: 'Students Performance Prediction',
    status: 'Completed',
    description:
      'A machine learning web system that predicts student academic performance and GPA risk from study habits and attendance data.',
    problem:
      'Early academic risk detection is often unavailable; a quick data-driven estimate allows universities to provide timely tutoring interventions.',
    features: [
      'Trained classification & regression models (Random Forest, Gradient Boosting)',
      'Simple interactive sliders for student study habits and attendance',
      'Instant predicted GPA and academic risk classification',
      'Actionable tutoring and academic advisor guidance',
    ],
    tech: ['Python', 'Scikit-learn', 'Pandas', 'NumPy', 'FastAPI', 'React'],
    repo: 'https://github.com/samuelmola963/student-performance-prediction',
    demo: 'interactive',
    image: '/src/assets/images/project_student_prediction_1793967657385.jpg',
    liveDemoType: 'student_prediction',
  },
  {
    id: 'campus-attendance',
    title: 'Campus Smart Attendance & QR Verifier',
    status: 'Completed',
    description:
      'Geofenced dynamic QR code attendance tracking system replacing paper sign-in sheets in university lecture halls.',
    problem:
      'Paper attendance sheets waste 10+ minutes of lecture time and suffer from student proxy signatures and lost records.',
    features: [
      'Dynamic rotating QR codes refreshing every 15 seconds to prevent sharing',
      'Lecture hall Wi-Fi and geofenced radius verification',
      'Instructor live presence radar and CSV export for university registrar',
    ],
    tech: ['React', 'TypeScript', 'Node.js', 'Express', 'Tailwind CSS'],
    repo: 'https://github.com/samuelmola963/campus-qr-attendance',
    demo: '',
    image: '/src/assets/images/project_lost_and_found_1793967644390.jpg',
  },
  {
    id: 'portfolio-website',
    title: 'Responsive Personal Portfolio',
    status: 'Completed',
    description:
      'This website, built with React, Tailwind CSS, and TypeScript, engineered for speed and clean design.',
    problem:
      'I needed one fast, accessible place to present my skills, university projects, and interactive demos to recruiters.',
    features: [
      'Light and dark theme with persistent local storage',
      'Data-driven skills and project repository showcase',
      'Integrated in-browser live demo simulators for flagship projects',
      'Accessible, responsive layout deployed on GitHub Pages',
    ],
    tech: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
    repo: 'https://github.com/samuelmola963/portfolio',
    demo: 'https://devsolan1.github.io/portfolio/',
    image: '/src/assets/images/project_student_prediction_1793967657385.jpg',
  },
];
